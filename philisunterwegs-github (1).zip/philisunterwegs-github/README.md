# Phil ist unterwegs

Erste Version des Reiseblogs für GitHub Pages.

## Veröffentlichung mit GitHub Pages

1. Neues GitHub-Repository anlegen, z. B. `philisunterwegs`.
2. Alle Dateien aus diesem Ordner in das Repository hochladen. `index.html` muss direkt im Hauptordner liegen.
3. In GitHub: **Settings → Pages**.
4. Unter **Build and deployment**: **Deploy from a branch** wählen.
5. Branch **main**, Ordner **/(root)** wählen und speichern.
6. Nach kurzer Zeit zeigt GitHub die öffentliche Pages-Adresse an.

## Struktur

- `index.html` – Startseite
- `style.css` – Design
- `script.js` – Menü und Fotogalerie
- `assets/` – erste ausgewählte Fotos

Die Texte sind vorläufig und können später mit echten Orten, Daten und Reisegeschichten ersetzt werden.
